//
//  Utilities.c
//  w6_lab
//
//  Created by Noston Liu on 2019/10/27.
//  Copyright © 2019 Noston. All rights reserved.
//

// Name: YuChe Liu
// Seneca Student ID: 134379189
// Seneca email: yliu545
// Date of completion: 10/31 , 2019
#include <string>
#include <iostream>
#include <sstream>

#include "Vehicle.h"

#include "Utilities.h"
#include "Car.h"

namespace sdds {
   Vehicle* createInstance(std::istream& in){
       Vehicle* temp = nullptr;
      
    //  char tag = '\0' ;
    //  bool find = true ;
    //  std::string t_string ;
    //  std::getline(in, t_string,'\n');
  
    //  for( int i = 0 ; i < t_string.size() && find; i++){
    //      if ( t_string[i] != ' ' ){
    //          tag = t_string[i];
    //          find = false;
    //      }
    //  }
       char type = in.get() ;
       //get ( in , type);
       switch ( type ) {
           case 'c':
           case 'C':
               return new Car(in);
               break;
           default:
               temp = nullptr;
               break;
       }
       return temp;
   };
    // v2
  // Vehicle* createInstance(std::istream& in){
  //     std::string line ;
  //     std::getline(in, line, '\n');
  //     std::stringstream ss(line);
  //     char type , delim;
  //     ss >> type >> delim;
  //
  //     switch (type) {
  //         case 'c':
  //         case 'C':
  //             return new Car(in);
  //             break;
  //        // default:
  //     }
  //     return nullptr;

  // }
}
